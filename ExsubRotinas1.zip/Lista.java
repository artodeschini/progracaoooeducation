
public class Lista {
	
	String[] dados = null;
	int i = -1;
	
	//Sub rotinas de Lista
	
	/**
	 * @return retorna se o array dados est� ou n�o declarado
	 */
	boolean isEmpty() {
		if ( dados == null ) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Faz com que a String str passada por parametro seja colocada
	 * no array dados, caso o array tenha alcan�ado o seu tamanho
	 * m�ximo ent�o faz uma copia e levas os valores para copia
	 * por fim essa c�pia ser� referenciada pelo array dados
	 * @param str
	 */
	void add(String str) {
		//controlar duplicidades
//		if ( contains(str) ) {
//			System.out.println(str + " j� foi adicionada");
//			return;
//		}
		
		if ( isEmpty() ) {
			dados = new String[10];
		}
		
		i++;
		
		if ( dados.length <= i ) {
			String[] copia = new String[dados.length + 10];
			for (int j = 0; j < dados.length; j++) {
				copia[j] = dados[j];
			}
			dados = copia;
		}
		
		dados[i] = str;
	}
	
	/**
	 * @return o n�mero de elementos adicionados
	 */
	int size() {
		return i;
	}
	
	/**
	 * Faz com que sejam listados todas as palavras adicionadas 
	 */
	void list() {
		for (int j = 0; j <= i ; j++) {
			System.out.println( dados[j] );
		}
	}
	
	/**
	 * 
	 * @param str
	 * @return verifica se uma String str foi j� adicionada
	 */
	boolean contains(String str) {
		boolean has = false;
		
		for (int j = 0; j <= i; j++) {
			if ( str.equals( dados[j] ) ) {
				has = true;
				break;
			}
		}
		
		return has;
	}
	
	/**
	 * @return retorna a ultima String adicionada removendo ela da
	 * lista
	 */
	String remove() {
		String removida = null;
		if ( ! isEmpty() ) {
			removida = dados[i];
			dados[i] = null;
			
			if ( i == 0 ) {
				dados = null;
			}
			
			i--;
		}
		
		return removida;
	}
	
	/**
	 * @param pos
	 * @param valor
	 * Altera o valor da posi��o pos pelo valor passado por parametro
	 * Se essa posi��o existir
	 */
	void set(int pos, String valor) {
		
		if ( ! isEmpty() ) {
			
			if ( pos > -1 && pos <= i ) {
				dados[pos] = valor;
			} else {
				System.out.println("Est� posi��o nao existe");
			}
			
		} else {
			System.out.println("Lista vazia");
		}
	}
	
	/**
	 * 
	 * @param pos
	 * @return a String que est� na posi��o pos passada por parametro
	 */
	String get(int pos) {
		String valor = null;
		
		if ( ! isEmpty() ) {
			
			if ( pos > -1 && pos <= i ) {
				valor = dados[pos];
			} else {
				System.out.println("Est� posi��o nao existe");
			}
			
		} else {
			System.out.println("Lista vazia");
		}
		
		return valor;
	}
	
	/**
	 * 
	 * @param str
	 * @return int da primeira posi��o que a palavra foi encontrada
	 * na lista de palavras caso n�o encontre retornar -1. 
	 */
	int indexOf(String str) {
		if ( ! isEmpty() ) {
			for (int j = 0; j <= i; j++) {
				if ( str.equals( dados[j] ) ) {
					return j;
				}
			}
		}
		return -1;
	}
	
	/**
	 * 
	 * @param str
	 * @return O �ltimo indice da str passada por par�metro
	 * caso n�o encontre retornar� -1
	 */
	int lastIndexOf(String str) {
		if ( ! isEmpty() ) {
			for (int j = i; j >= 0; j--) {
				if ( str.equals( dados[j] ) ) {
					return j;
				}
			}
		}
		return -1;
	}
	
	/**
	 * 
	 * @param str
	 * @return retorna a quantidade de vezes que uma palavra �
	 * encontrada na lista
	 */
	int rowCount(String str) {
		int cont = 0;
		
		if ( ! isEmpty() ) {
			
			int j = 0;
			
			while ( j <= i) {
				
				if ( str.equals( dados[j] ) ) {
					cont++;
				}
				
				j++;
			}
		}
		
		return cont;
	}

}
