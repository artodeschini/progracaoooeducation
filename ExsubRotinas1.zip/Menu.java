import java.util.Scanner;

public class Menu {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Lista l = new Lista();
		
		String menu = 
				"1 - Adicionar\n" +
				"2 - Remover\n" +
				"3 - Verificar quantidade adicionadas.\n" +
				"4 - Verificar se uma palavra j� foi adicionada.\n" +
				"5 - Verificar se a lista est� vazia.\n" +
				"6 - Listar os valores.\n" +
				"7 - Alterar um valor de uma determinada posi��o.\n" +
				"8 - Pegar um valor de uma determinada posi��o.\n" +
				"9 - Obt�m o �ndice da palavra\n" +
				"10 - Obt�m o �ltimo �ndice da palavra\n" +
				"11 - Verificar quantas vezes a palavra � encontrada\n" +
				"12 - Sair";
		
		System.out.println( menu );
		//String str = JOptionPane.showInputDialog( menu );
		int op = sc.nextInt();
		
		while ( op != 12 ) {
			switch ( op ) {
			case 1:
				System.out.println("Adicione uma palavra");
				String parametro = sc.next();
				l.add( parametro );
				break;
			case 2:
				if ( l.isEmpty() ) {
					System.out.println("lista vazia");
					
				} else {
					String removida = l.remove();
					System.out.println(
							"Palavra " + removida + 
							" removida da lista" );
				}
				break;
			case 3:
				System.out.println("n�mero de palavras adicionadas ");
				System.out.println( l.size() );
				break;
			case 4:
				System.out.println("Digite uma palavra");
				String compara = sc.next();
				
				System.out.println( 
						l.contains( compara )
						? "J� foi adicionada" : "nao adicionada");
				break;
			case 5:
				System.out.println( l.isEmpty() ? "Vazia" :"h� elementos" );
				break;
			case 6:
				if ( l.isEmpty() ) {
					System.out.println("Lista vazia");
				} else {
					l.list();
				}
				break;
			case 7:
				System.out.println("Digite a posi��o a ser alterada");
				int pos = sc.nextInt();
				System.out.println("Digite uma palavra para alterar");
				String valor = sc.next();
				l.set(pos, valor);
				break;
			case 8:
				System.out.println("Digite a posi��o a ser pegada");
				int pos2 = sc.nextInt();
				String valorPego = l.get(pos2);
				if ( valorPego != null) {
					System.out.println("Valor pego " + valorPego);
				}
				break;
			case 9:
				System.out.println("Digite uma palavra");
				String compara2 = sc.next();
				int index = l.indexOf( compara2 );
				System.out.println(index > -1 
						? "O indice e " + index 
						: "Palavra " + compara2 + " nao encontrada");
				break;
			case 10:
				System.out.println("Digite uma palavra");
				String compara3 = sc.next();
				int lastIndex = l.lastIndexOf( compara3 );
				System.out.println(lastIndex > -1 
						? "O �ltimo indice e " + lastIndex 
						: "Palavra " + compara3 + " nao encontrada");
				break;
			case 11:
				System.out.println("Digite uma palavra");
				String compara4 = sc.next();
				System.out.println("Quantidade encontra da palavra "
						+ compara4 + " � " + l.rowCount( compara4 ) );
				break;
				
			default:
				System.out.println("Op��o invalida");
				break;
			}
			
			System.out.println( menu );
			op = sc.nextInt();
		}

	}

}
