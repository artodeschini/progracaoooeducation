import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;

import sc.br.senai.ctrl.ControleTelaPrincipal;
import sc.br.senai.ctrl.util.LocalPadraoSistema;
import sc.br.senai.ctrl.view.SelecionaLocal;


/**
 * @author senai
 */
public class Run {
    
    private static LocalPadraoSistema lps;
    private static SelecionaLocal sl;
    
    public static void main(String[] args) {
        sl = new SelecionaLocal();
        sl.setVisible(true);
        
        sl.jbIngles.addActionListener( new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	//chame o metodo criado passando em LocalPadraoSistema passando um
            	//Locale en US
                lps.setLocalPadraoSistema(new Locale("en","US"));
                executeTelaPrincipal();
                
            }
        });
       
      
       sl.jbPortugues.addActionListener( new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	//chame o metodo criado passando em LocalPadraoSistema passando um
            	//Locale pt BR
                lps.setLocalPadraoSistema(new Locale("pt","BR"));
                executeTelaPrincipal();
   
                
            }
        });
    }
    
    private static void executeTelaPrincipal() {
    	sl.setVisible(false);
        ControleTelaPrincipal cp = new ControleTelaPrincipal();
        cp.execute();
    }
    
}
