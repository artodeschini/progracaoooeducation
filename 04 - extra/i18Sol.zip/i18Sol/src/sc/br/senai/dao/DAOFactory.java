
package sc.br.senai.dao;

/**
 *
 * @author artur
 */
public abstract class DAOFactory {
    
    private static CidadeDAO cidadeDAO;
    private static PessoaDAO pessoaDAO;
    
    public static CidadeDAO getCidadeDAO() {
        if ( cidadeDAO == null) {
            cidadeDAO = new ImplCidadeDAO();
        }
        
        if ( cidadeDAO.isConnectionClose() ) {
        	cidadeDAO.openConnection();
        }
        
        return cidadeDAO;
    }
    
    public static PessoaDAO getPessoaDAO() {
    	if ( pessoaDAO == null ) {
    		pessoaDAO = new ImplPessoaDAO();
    	}
    	
    	if ( pessoaDAO.isConnectionClose() ) {
    		pessoaDAO.openConnection();
    	}
    	
    	return pessoaDAO;
    }
}
