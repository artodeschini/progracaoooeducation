package sc.br.senai.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author vdiguest0576
 */
class MySQLConnectionManeger extends ConnectionManeger {
    
    private static final String NOME_BANCO = "trabalho1";
    private static final String PATH_DRIVER = "com.mysql.jdbc.Driver";
    private static final String IP_BANCO = "localhost";
    private static final String USR_BANCO = "root";
    private static final String PASS_BANCO = "";
    private static final String CONN = "jdbc:mysql://" + IP_BANCO + "/" + NOME_BANCO;

    MySQLConnectionManeger() {}
    
    @Override
    public Connection getConnection() {
        return getConnection(true);
    }
    
    public Connection getConnection(boolean useTransaction) {
        Connection connection = null;
        try {
            Class.forName(PATH_DRIVER);
            connection = DriverManager.getConnection(CONN, USR_BANCO, PASS_BANCO);
            connection.setAutoCommit(useTransaction);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MySQLConnectionManeger.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(MySQLConnectionManeger.class.getName()).log(Level.SEVERE, null, ex);
        }
        return connection;
    }
    public  void closeConnection(Connection connection) {
        closeConnection(connection, false);
    }
    
    public void closeConnection(Connection connection, boolean useTranscation) {
        try {
            if ( useTranscation ) {
                connection.commit();
            }
            
            connection.close();
        } catch (SQLException ex) {
            Logger.getLogger(MySQLConnectionManeger.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
//    
//    public static void main(String[] args) {
//        ConnectionManeger cm = new ConnectionManeger();
//        Connection conn = cm.getConnection();
//        cm.closeConnection(conn);
//    }
}
