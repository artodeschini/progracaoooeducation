/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sc.br.senai.dao;

import java.util.List;

import sc.br.senai.model.Cidade;

/**
 *
 * @author vdiguest0576
 */
public interface CidadeDAO extends AbstractDAO<Cidade> {
    
    List<Cidade> buscaCidadesPorNome(Cidade cidade);
    
    List<Cidade> buscaCidadesPorUF(Cidade cidade);
    
}
