/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sc.br.senai.dao;

import java.util.List;

/**
 *
 * @author vdiguest0576
 */
public interface AbstractDAO<E> {
    
    E salvar(E e);
    void alterar(E e);
    void deletar(E e);
    List<E> findAll();
    boolean isConnectionClose();
    void openConnection();
    
}
