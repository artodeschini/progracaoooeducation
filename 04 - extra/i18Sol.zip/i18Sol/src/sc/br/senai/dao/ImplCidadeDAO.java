package sc.br.senai.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import sc.br.senai.model.Cidade;

/**
 * @author artur
 */
class ImplCidadeDAO implements CidadeDAO {

	private final String LIKE = "select idcidade, nmcidade, sgestado from encidade where nmcidade like ?";
	private final String ALL = "select idcidade, nmcidade, sgestado from encidade";
	private final String UF = "select idcidade, nmcidade, sgestado from encidade where sgestado = ?";
	private final String INSERT = "insert into encidade (nmcidade, sgestado) values (?,?)";
	private final String UPDATE = "update encidade set nmcidade = ?, sgestado = ? where idcidade = ?";
	private final String DELETE = "delete from encidade where idcidade = ?";

	private Connection connection;
	private boolean usaTransaction = false;

	public ImplCidadeDAO() {
		ConnectionManeger connectionManeger = ConnectionManeger.getConnectionManager();
		connection = connectionManeger.getConnection();
		usaTransaction = true;
	}

	public ImplCidadeDAO(boolean useTansacao) {
		ConnectionManeger connectionManeger = ConnectionManeger.getConnectionManager();
		connection = connectionManeger.getConnection(useTansacao);
		usaTransaction = useTansacao;
	}

	@Override
	public List<Cidade> buscaCidadesPorNome(Cidade cidade) {
		List<Cidade> cidades = new ArrayList<Cidade>();
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = connection.prepareStatement(LIKE);
			ps.setObject(1, "%" + cidade.getNmCidade() + "%");

			rs = ps.executeQuery();

			while (rs.next()) {
				cidades.add(new Cidade(
						rs.getInt("idcidade"),
						rs.getString("nmcidade"),
						rs.getString("sgestado")));
			}

		} catch (SQLException ex) {
			Logger.getLogger(ImplCidadeDAO.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			try {
				if (!usaTransaction) {
					connection.commit();
				}
				connection.close();
			} catch (SQLException s) {
				s.printStackTrace();
			}
		}
		return cidades;
	}

	@Override
	public List<Cidade> buscaCidadesPorUF(Cidade cidade) {
		List<Cidade> cidades = new ArrayList<Cidade>();

		try {
			PreparedStatement ps = null;
			ResultSet rs = null;
			ps = connection.prepareStatement(UF);
			ps.setObject(1, cidade.getSgEstado());

			rs = ps.executeQuery();

			while (rs.next()) {
				cidades.add(new Cidade(
						rs.getInt("idcidade"),
						rs.getString("nmcidade"),
						rs.getString("sgestado")));
			}

		} catch (SQLException ex) {
			Logger.getLogger(ImplCidadeDAO.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			try {
				if (!usaTransaction) {
					connection.commit();
				}
				connection.close();
			} catch (SQLException s) {
				s.printStackTrace();
			}
		}

		return cidades;
	}

	@Override
	public Cidade salvar(Cidade c) {
		try {
			PreparedStatement ps = null;
			ps = connection.prepareStatement(INSERT, PreparedStatement.RETURN_GENERATED_KEYS);
			ps.setObject(1, c.getNmCidade());
			ps.setObject(2, c.getSgEstado());

			ps.executeUpdate();
			ResultSet rs = ps.getGeneratedKeys();
		    rs.next();
		    
		    c.setIdCidade( rs.getInt(1));

		} catch (SQLException ex) {
			Logger.getLogger(ImplCidadeDAO.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			try {
				if (!usaTransaction) {
					connection.commit();
				}
				connection.close();
			} catch (SQLException s) {
				s.printStackTrace();
			}
		}
		return c;
	}

	@Override
	public void alterar(Cidade e) {
		try {
			PreparedStatement ps = null;
			ps = connection.prepareStatement(UPDATE);
			ps.setObject(1, e.getNmCidade());
			ps.setObject(2, e.getSgEstado());
			ps.setObject(3, e.getIdCidade());

			ps.executeUpdate();

		} catch (SQLException ex) {
			Logger.getLogger(ImplCidadeDAO.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			try {
				if (!usaTransaction) {
					connection.commit();
				}
				connection.close();
			} catch (SQLException s) {
				s.printStackTrace();
			}
		}
	}

	@Override
	public void deletar(Cidade e) {
		try {
			PreparedStatement ps = null;
			ps = connection.prepareStatement(DELETE);
			ps.setObject(1, e.getIdCidade());

			ps.executeUpdate();

		} catch (SQLException ex) {
			Logger.getLogger(ImplCidadeDAO.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			try {
				if (!usaTransaction) {
					connection.commit();
				}
				connection.close();
			} catch (SQLException s) {
				s.printStackTrace();
			}
		}
	}

	@Override
	public List<Cidade> findAll() {
		List<Cidade> cidades = new ArrayList<Cidade>();

		try {
			PreparedStatement ps = null;
			ResultSet rs = null;
			ps = connection.prepareStatement(ALL);

			rs = ps.executeQuery();

			while (rs.next()) {
				cidades.add(new Cidade(
						rs.getInt("idcidade"),
						rs.getString("nmcidade"),
						rs.getString("sgestado")));
			}

		} catch (SQLException ex) {
			Logger.getLogger(ImplCidadeDAO.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			try {
				if (!usaTransaction) {
					connection.commit();
				}
				connection.close();
			} catch (SQLException s) {
				s.printStackTrace();
			}
		}

		return cidades;

	}

	@Override
	public boolean isConnectionClose() {
		try {
			return connection.isClosed();
		} catch (SQLException ex) {
			return false;
		}
	}

	@Override
	public void openConnection() {
		ConnectionManeger cm = ConnectionManeger.getConnectionManager();
		connection = cm.getConnection();
	}
	// public static void main(String[] args) {
	// CidadeDAO dao = new ImplCidadeDAO();
	// //teste inserir cidade
	// Cidade c = new Cidade(1, "Floripa", "SC");
	// dao.salvar(c);
	//
	// //teste alterar cidade
	// Cidade c = new Cidade(2,"Chapeco","SC");
	// dao.alterar(c);
	// }

}
