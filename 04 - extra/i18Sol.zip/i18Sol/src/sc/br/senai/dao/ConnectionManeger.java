package sc.br.senai.dao;

import java.io.IOException;
import java.sql.Connection;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;


import sc.br.senai.ctrl.util.ReadFileConfig;

/**
 *
 * @author artur
 */
public abstract class ConnectionManeger {

    private static ConnectionManeger cm = null;

    public abstract Connection getConnection();

    public abstract Connection getConnection(boolean useTransaction);

    public abstract void closeConnection(Connection connection);

    public abstract void closeConnection(Connection connection, boolean useTranscation);

    public static ConnectionManeger getConnectionManager() {
        if (cm == null) {
            //Locale l = new Locale("","");
            ResourceBundle bundle = ResourceBundle.getBundle("propriedade");
            
            String tpbanco = bundle.getString("tpbanco");
            System.out.println(tpbanco);
            
            if ( tpbanco.equals("mysql") ) {
                cm = new MySQLConnectionManeger();
            }
            //System.out.println(bundle.getString("welcome"));

//            Map<String, String> map = null;
//            ReadFileConfig rf = new ReadFileConfig();
//            try {
//                //map = rf.getPropriedadeSistema("src/sc/br/senai/dao/propriedade.properties");
//                if ( map.get("tpbanco").equals("mysql")) {
//                    cm = new MySQLConnectionManeger();
//                } else if (map.get("tpbanco").equals("oracle")) {
//                }
//            } catch (IOException ex) {
//                cm = new MySQLConnectionManeger();
//            }
        }
        return cm;
    }
    
    
    public static void main(String[] args) {
        getConnectionManager();
    }
}
