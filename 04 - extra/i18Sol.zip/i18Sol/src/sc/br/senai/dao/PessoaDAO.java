/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sc.br.senai.dao;

import java.util.List;

import sc.br.senai.model.Pessoa;
import sc.br.senai.model.PessoaF;
import sc.br.senai.model.PessoaJ;

/**
 *
 * @author vdiguest0576
 */
public interface PessoaDAO extends AbstractDAO<Pessoa> {
    
    List<Pessoa> findAllPessoasJuridicas();
    List<Pessoa> findAllPessoasFisicas();
    List<Pessoa> findPessoasPorNome(Pessoa pessoa);
    List<Pessoa> findAllPessoasByCidade(Pessoa pessoa);
    PessoaJ findPessoaByCnpj(Pessoa pessoa);
    PessoaF findPessoaByCpf(Pessoa pessoa);
}
