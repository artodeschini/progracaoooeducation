package sc.br.senai.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import sc.br.senai.model.Pessoa;
import sc.br.senai.model.PessoaF;
import sc.br.senai.model.PessoaJ;

class ImplPessoaDAO implements PessoaDAO {
	
	
	
	private final String INSERT = "insert into enpessoa " +
		"(nmpessoa,nmsobrenome,dtnascimento,tppessoa,numero,idcidade) values (?,?,?,?,?,?)";
	
	//"update encidade set nmcidade = ?, sgestado = ? where idcidade = ?
	private final String UPDATE = "update enpessoa set nmpessoa = ? ,nmsobrenome = ? ,dtnascimento = ?, " +
	    " numero = ? , idcidade = ?  where idpessoa = ?";
	
	private final String DELETE = "delete form enpessoa where idpessoa = ?";
	
	private final String SELECT = "select p.tppessoa, p.nmpessoa, p.nmsobrenome, " + 
		"p.dtnascimento, p.numero, p.idcidade, c.nmcidade, c.sgestado " +
		" from enpessoa p inner join encidade c on " +
		" c.idcidade = p.idcidade ";

	private Connection connection;
	private boolean usaTransaction = false;
	
	public ImplPessoaDAO() {
		ConnectionManeger cm = ConnectionManeger.getConnectionManager();
		connection = cm.getConnection();
		usaTransaction = true;
	}

	public ImplPessoaDAO(boolean useTansacao) {
		ConnectionManeger connectionManeger = ConnectionManeger.getConnectionManager();
		connection = connectionManeger.getConnection(useTansacao);
		usaTransaction = useTansacao;
	}

	@Override
	public Pessoa salvar(Pessoa p) {
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			int i = 1;
			ps = connection.prepareStatement(INSERT, PreparedStatement.RETURN_GENERATED_KEYS);
			ps.setObject(i++, p.getNmPessoa() );
			ps.setObject(i++, p.getNmSobrenome() );
			
			if ( p.getTipo() == Pessoa.PF ) {
				ps.setDate(i++, new java.sql.Date( ( ( PessoaF ) p).getDtNascimento().getTime() ) );
			} else {
				ps.setDate(i++, null);
			}
			
			ps.setObject(i++, p.getTipo() );
			ps.setObject(i++, p.getNumero() );
			ps.setObject(i++, p.getC().getIdCidade() );
			
			ps.executeUpdate();
			rs = ps.getGeneratedKeys();
		    rs.next();
		    
		    p.setIdPessoa( rs.getInt(1) );
		    
		} catch (SQLException e) {
			Logger.getLogger(ImplPessoaDAO.class.getName()).log(Level.SEVERE, null, e);
		} finally {
			try {
				if (!usaTransaction) {
					connection.commit();
				}
				connection.close();
			} catch (SQLException s) {
				s.printStackTrace();
			}
		}
		
		return p;
	}

	@Override
	public void alterar(Pessoa p) {
		PreparedStatement ps = null;
		try {
			int i = 1;
			ps = connection.prepareStatement(UPDATE);
			ps.setObject(i++, p.getNmPessoa() );
			ps.setObject(i++, p.getNmSobrenome() );
			
			if ( p.getTipo() == Pessoa.PF ) {
				ps.setDate(i++, new java.sql.Date( ( ( PessoaF ) p).getDtNascimento().getTime() ) );
			} else {
				ps.setDate(i++, null);
			}
			
			ps.setObject(i++, p.getNumero() );
			ps.setObject(i++, p.getC().getIdCidade() );
			ps.setObject(i++, p.getIdPessoa() );
			
			ps.executeUpdate();
			
		} catch (SQLException e) {
			Logger.getLogger(ImplPessoaDAO.class.getName()).log(Level.SEVERE, null, e);
		} finally {
			try {
				if (!usaTransaction) {
					connection.commit();
				}
				connection.close();
			} catch (SQLException s) {
				s.printStackTrace();
			}
		}
	}

	@Override
	public void deletar(Pessoa p) {
		PreparedStatement ps = null;
		try {
			int i = 1;
			ps = connection.prepareStatement(DELETE);
			ps.setObject(i++, p.getC().getIdCidade() );
			
			ps.executeUpdate();
		    
		} catch (SQLException e) {
			Logger.getLogger(ImplPessoaDAO.class.getName()).log(Level.SEVERE, null, e);
		} finally {
			try {
				if (!usaTransaction) {
					connection.commit();
				}
				connection.close();
			} catch (SQLException s) {
				s.printStackTrace();
			}
		}
	}

	@Override
	public List<Pessoa> findAll() {
		return this.findPessoasGenerico(null, null);
	}

	@Override
	public List<Pessoa> findAllPessoasJuridicas() {
		return this.findPessoasGenerico(null, Pessoa.PJ);
	}

	@Override
	public List<Pessoa> findAllPessoasFisicas() {
		return this.findPessoasGenerico(null, Pessoa.PF);
	}

	@Override
	public List<Pessoa> findPessoasPorNome(Pessoa pessoa) {
		return this.findPessoasGenerico(pessoa, 3);
	}

	@Override
	public List<Pessoa> findAllPessoasByCidade(Pessoa pessoa) {
		return this.findPessoasGenerico(pessoa, 4);
	}

	@Override
	public PessoaJ findPessoaByCnpj(Pessoa pessoa) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PessoaF findPessoaByCpf(Pessoa pessoa) {
		// TODO Auto-generated method stub
		return null;
	}
	
	private List<Pessoa>findPessoasGenerico(Pessoa p, Integer tipo) {
		List<Pessoa> pessoas = new ArrayList<Pessoa>();
		PreparedStatement ps = null;
		
		try {
			
			StringBuilder sql = new StringBuilder(SELECT);
			if ( p != null ) {
				sql.append(" where ");
				
				
				switch (tipo) {
					case 3:
						//findPessoasPorNome = 3
						sql.append(" p.nmpessoa = ? ");
						break;
					case 4:
						//findAllPessoasByCidade = 4
						sql.append(" p.idcidade = ? ");
						break;
				}	
				
				
				
			} else if ( tipo != null ) {
				
				sql.append(" where ");
				switch ( tipo ) {
					
					case Pessoa.PF: 
						sql.append(" p.tppessoa = ? ");
						break;
					
					case Pessoa.PJ:
						sql.append(" p.tppessoa = ? ");
						break;
				}
			}
			
			int i = 0;
			
			ps = connection.prepareStatement( sql.toString() );
			if ( p != null && tipo != null) {
				ps.setObject(i++, tipo);
			} else {
				
				switch (tipo) {
					case 3:
						//findPessoasPorNome = 3
						ps.setObject(i++, p.getNmPessoa() );
						break;
					case 4:
						//findAllPessoasByCidade = 4
						ps.setObject(i++, p.getC().getIdCidade() );
						break;
				}
			}
			
			ResultSet rs = ps.executeQuery();
			Pessoa pessoa = null;
			int type = 0;
			
			while ( rs.next() ) {
		    
				type =  rs.getInt("tppessoa");
				
				if ( type == Pessoa.PF) {
					pessoa = new PessoaF();
				} else {
					pessoa = new PessoaJ();
				}
				
				pessoa.setTipo(type);
				pessoa.setIdPessoa(rs.getInt("idpessoa"));
				pessoa.setNmPessoa( rs.getString("nmpessoa"));
				pessoa.setNmSobrenome( rs.getString("nmsobrenome"));
				
				if ( type == Pessoa.PF ) {
					((PessoaF )pessoa).setDtNascimento(rs.getDate("dtnascimento"));	
				}
				
				pessoa.setNumero( rs.getString("numero"));
				pessoa.getC().setIdCidade(rs.getInt("idcidade"));
				pessoa.getC().setNmCidade(rs.getString("nmcidade"));
				pessoa.getC().setSgEstado(rs.getString("sgestado"));
				
				pessoas.add(pessoa);
			}
			
		} catch (SQLException e) {
			Logger.getLogger(ImplPessoaDAO.class.getName()).log(Level.SEVERE, null, e);
		}
		
		return pessoas; 
	}

	@Override
	public boolean isConnectionClose() {
		try {
			return connection.isClosed();
		} catch (SQLException e) {
			return false;
		}
	}

	@Override
	public void openConnection() {
		ConnectionManeger cm = ConnectionManeger.getConnectionManager();
		connection = cm.getConnection();
	}
}
