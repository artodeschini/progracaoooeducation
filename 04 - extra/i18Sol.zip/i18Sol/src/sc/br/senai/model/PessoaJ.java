
package sc.br.senai.model;

import java.util.Date;

/**
 *
 * @author artur
 */
public class PessoaJ extends Pessoa {
    
	private static final long serialVersionUID = 6194384858740551165L;

    public PessoaJ() {
        super.setIdPessoa(-1);
        super.setNmPessoa("");
        setNomeFantasia("");
        super.setNumero("");
        super.setTipo(Pessoa.PJ);
        
    }
    
    public PessoaJ(int idPessoa, String nmPessoa, String nmFantasia, String numero, String cnpj, Date dtNascimento) {
        super.setIdPessoa(idPessoa);
        super.setNmPessoa(nmPessoa);
        setNomeFantasia(nmFantasia);
        super.setNumero(numero);
        super.setTipo(Pessoa.PJ);
    }

    public String getCnpj() {
        return super.getNumero();
    }

    public void setCnpj(String cnpj) {
        super.setNumero(cnpj);
    }

    public String getNomeFantasia() {
        return super.getNmSobrenome();
    }

    public void setNomeFantasia(String nomeFantasia) {
       super.setNmSobrenome(nomeFantasia);
    }
    
}
