
package sc.br.senai.model;

import java.io.Serializable;

/**
 * @author artur
 */
public abstract class Pessoa implements Serializable {
    
	private static final long serialVersionUID = -4612547373984921547L;
	
	public static final int PF = 1;
    public static final int PJ = 2;
    
    public static final String DPF = "Fisica";
    public static final String DPJ = "Juridica";
    
    private int idPessoa;
    private String nmPessoa;
    private String nmSobrenome;
    private String numero;
    private int tipo;
    
    private Cidade c;

    /**
     * @return the idPessoa
     */
    public int getIdPessoa() {
        return idPessoa;
    }

    /**
     * @param idPessoa the idPessoa to set
     */
    public void setIdPessoa(int idPessoa) {
        this.idPessoa = idPessoa;
    }

    /**
     * @return the nmPessoa
     */
    public String getNmPessoa() {
        return nmPessoa;
    }

    /**
     * @param nmPessoa the nmPessoa to set
     */
    public void setNmPessoa(String nmPessoa) {
        this.nmPessoa = nmPessoa;
    }

    /**
     * @return the numero
     */
    public String getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(String numero) {
        this.numero = numero;
    }

    /**
     * @return the tipo
     */
    public int getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(int tipo) {
        if ( tipo == Pessoa.PF || tipo == Pessoa.PJ) {
            this.tipo = tipo; 
        } else {
            this.tipo = Pessoa.PF;
        }
    }

    public Cidade getC() {
    	if ( c == null) {
    		c = new Cidade();
    	}
        return c;
    }

    public void setC(Cidade c) {
        this.c = c;
    }

    public String getNmSobrenome() {
        return nmSobrenome;
    }

    public void setNmSobrenome(String nmSobrenome) {
        this.nmSobrenome = nmSobrenome;
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((nmPessoa == null) ? 0 : nmPessoa.hashCode());
		result = prime * result
				+ ((nmSobrenome == null) ? 0 : nmSobrenome.hashCode());
		result = prime * result + ((numero == null) ? 0 : numero.hashCode());
		result = prime * result + tipo;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pessoa other = (Pessoa) obj;
		if (nmPessoa == null) {
			if (other.nmPessoa != null)
				return false;
		} else if (!nmPessoa.equals(other.nmPessoa))
			return false;
		if (nmSobrenome == null) {
			if (other.nmSobrenome != null)
				return false;
		} else if (!nmSobrenome.equals(other.nmSobrenome))
			return false;
		if (numero == null) {
			if (other.numero != null)
				return false;
		} else if (!numero.equals(other.numero))
			return false;
		if (tipo != other.tipo)
			return false;
		return true;
	}
    
}
