package sc.br.senai.model;

import java.util.Date;

/**
 *
 * @author artur
 */
public class PessoaF extends Pessoa {
    
	private static final long serialVersionUID = -295843249507530188L;
	
    private Date dtNascimento;

    public PessoaF() {
        super.setIdPessoa(-1);
        super.setNmPessoa("");
        super.setNmSobrenome("");
        super.setNumero("");
        super.setTipo(Pessoa.PF);
        this.dtNascimento = new Date();
    }
    public PessoaF(String cpf, Date dtNascimento) {
        this();
        super.setNumero(cpf);
        this.dtNascimento = dtNascimento;
    }
    
    public PessoaF(int idPessoa, String nmPessoa, String nmSobrenome, String numero, String cpf, Date dtNascimento) {
        super.setIdPessoa(idPessoa);
        super.setNmPessoa(nmPessoa);
        super.setNmSobrenome(nmSobrenome);
        super.setNumero(numero);
        super.setTipo(Pessoa.PF);
        this.dtNascimento = dtNascimento;
    }

    public String getCpf() {
        return super.getNumero();
    }

    public void setCpf(String cpf) {
        super.setNumero(cpf);
    }

    public Date getDtNascimento() {
        return dtNascimento;
    }

    public void setDtNascimento(Date dtNascimento) {
        this.dtNascimento = dtNascimento;
    }
    
}
