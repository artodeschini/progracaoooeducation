package sc.br.senai.ctrl.view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JScrollPane;
import javax.swing.JTable;

import sc.br.senai.ctrl.util.MyInternalFrame;
import sc.br.senai.ctrl.util.SimpleTableModel;
import sc.br.senai.model.Cidade;

/**
 * @author artur
 */
public class ResultadoCidadeView extends MyInternalFrame {

	private static final long serialVersionUID = 1299546315390084343L;
	
	public JTable jTable;
	private String[] colunas = { "C�digo", "Nome", "Estado" };
	private boolean[] editavel = { false, false, false };
	@SuppressWarnings("rawtypes")
	private List dados = new ArrayList();

	@SuppressWarnings("unchecked")
	public ResultadoCidadeView(String t, boolean r, boolean c, boolean m, boolean i, List<Cidade> cidades) {
		super(t, r, c, m, i);
		
		String[] city = null;
		for (Cidade cidade : cidades) {
			city = new String[3];
			city[0] = String.valueOf(cidade.getIdCidade());
			city[1] = cidade.getNmCidade();
			city[2] = cidade.getSgEstado();
			
			dados.add(city);
		}
		
		SimpleTableModel modelo = new SimpleTableModel(dados, colunas, editavel);
		jTable = new JTable(modelo);
		
		JScrollPane scroll = new JScrollPane(jTable);
		
		this.setLayout(new BorderLayout() );
	    Container container = this.getContentPane();
	    container.add(BorderLayout.CENTER, scroll);
	}

}
