package sc.br.senai.ctrl.view;

import javax.swing.JLabel;

import sc.br.senai.ctrl.util.MyInternalFrame;

/**
 * @author artur
 */
public class PessoaView extends MyInternalFrame {

	private static final long serialVersionUID = -234024651855327874L;
	private int acao;
	
	// p.tppessoa, p.nmpessoa, p.nmsobrenome,
	// p.dtnascimento, p.numero, p.idcidade
	private JLabel jlIdPessoa, jlNmPessoa, jlNmSobreNome, jlTpPessoa,
				   jlDtNascimento, jlNumero, jlCidade;
	
	
	public PessoaView(String t, boolean r, boolean c, boolean m, boolean i, int acao) {
		super(t, r, c, m, i);
		
		this.acao = acao;

	}

}
