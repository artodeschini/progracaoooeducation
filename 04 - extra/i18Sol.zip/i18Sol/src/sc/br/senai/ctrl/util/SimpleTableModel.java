package sc.br.senai.ctrl.util;

import java.util.Iterator;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class SimpleTableModel extends AbstractTableModel {

	private static final long serialVersionUID = -6067776854866334674L;
	
	@SuppressWarnings("rawtypes")
	private List linhas = null;
    private String[] colunas = null;
    private boolean[] colsEdicao;

    /**
     * Contrutor para a classe, recebendo os dados a serem exibidos e as colunas
     * que devem ser criadas.
     * 
     * @param dados
     * @param colunas
     */
    @SuppressWarnings("rawtypes")
	public SimpleTableModel(List dados, String[] colunas, boolean[] edicao) {
        setLinhas(dados);
        setColunas(colunas);
        colsEdicao = edicao;
    }

    /**
     * Retorna o numero de colunas no modelo
     * 
     * @see javax.swing.table.TableModel#getColumnCount()
     */
    public int getColumnCount() {
        return getColunas().length;
    }

    /**
     * Retorna o numero de linhas existentes no modelo
     * 
     * @see javax.swing.table.TableModel#getRowCount()
     */
    public int getRowCount() {
        return getRows().size();
    }

    /**
     * Obtem o valor na linha e coluna
     * 
     * @see javax.swing.table.TableModel#getValueAt(int, int)
     */
    public Object getValueAt(int rowIndex, int columnIndex) {
        // Obtem a linha, que e uma String []
        String[] linha = (String[]) getRows().get(rowIndex);
        // Retorna o objeto que esta na coluna
        return linha[columnIndex];
    }

    /**
     * @return the colunas
     * @uml.property name="colunas"
     */
    public String[] getColunas() {
        return colunas;
    }

    /**
     * @return the linhas
     * @uml.property name="linhas"
     */
    @SuppressWarnings("rawtypes")
	public List getRows() {
        return linhas;
    }

    /**
     * @param colunas
     *            the colunas to set
     * @uml.property name="colunas"
     */
    public void setColunas(String[] strings) {
        colunas = strings;
    }

    /**
     * @param linhas
     *            the linhas to set
     * @uml.property name="linhas"
     */
    @SuppressWarnings("rawtypes")
	public void setLinhas(List list) {
        linhas = list;
    }

    /**
     * Seta o valor na linha e coluna
     * 
     * @see javax.swing.table.TableModel#setValueAt(java.lang.Object, int, int)
     */
    public void setValueAt(Object value, int row, int col) {
        // Obtem a linha, que e uma String []
        String[] linha = (String[]) getRows().get(row);
        // Altera o conteudo no indice da coluna passado
        linha[col] = (String) value;
        // dispara o evento de celula alterada
        fireTableCellUpdated(row, col);
    }

    /**
     * Retorna se a celula pode ser editada
     * 
     * @see javax.swing.table.TableModel#isCellEditable(int, int)
     */
    public boolean isCellEditable(int row, int col) {
        return colsEdicao[col];
    }

    /**
     * Adiciona o array na linha
     */
    @SuppressWarnings("unchecked")
	public void addRow(String[] dadosLinha) {
        getRows().add(dadosLinha);
        // Informa a jtable de que houve linhas incluidas no modelo
        // COmo adicionamos no final, pegamos o tamanho total do modelo
        // menos 1 para obter a linha incluida.
        int linha = getRows().size() - 1;
        fireTableRowsInserted(linha, linha);
        return;
    }

    /**
     * Remove a linha pelo indice informado
     * 
     * @param row
     */
    public void removeRow(int row) {
        getRows().remove(0);
        // informa a jtable que houve dados deletados passando a
        // linha reovida
        fireTableRowsDeleted(row, row);
    }

    /**
     * Remove a linha pelo valor da coluna informada
     * 
     * @param val
     * @param col
     * @return
     */
    public boolean removeRow(String val, int col) {
        // obtem o iterator
        @SuppressWarnings("rawtypes")
		Iterator i = getRows().iterator();
        int linha = 0;
        // Faz um looping em cima das linhas
        while (i.hasNext()) {
            // Obtem as colunas da linha atual
            String[] linhaCorrente = (String[]) i.next();
            linha++;
            // compara o conteudo String da linha atual na coluna desejada
            // com o valor informado
            if (linhaCorrente[col].equals(val)) {
                getRows().remove(linha);
                // informa a jtable que houve dados deletados passando a
                // linha removida
                fireTableRowsDeleted(linha, linha);
                return true;
            }
        }
        // Nao encontrou nada
        return false;
    }

    /**
     * Retorna o nome da coluna.
     * 
     * @see javax.swing.table.TableModel#getColumnName(int)
     */
    public String getColumnName(int col) {
        return getColunas()[col];
    }
}
