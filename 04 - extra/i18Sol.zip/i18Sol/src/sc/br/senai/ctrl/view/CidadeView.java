
package sc.br.senai.ctrl.view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import javax.swing.*;

import sc.br.senai.ctrl.util.ConstantesViews;
import sc.br.senai.ctrl.util.FixedLengthDocument;
import sc.br.senai.ctrl.util.MyInternalFrame;

/**
 *
 * @author artur
 */
public class CidadeView extends MyInternalFrame {
    
	private static final long serialVersionUID = -3358255753405447842L;
	
	public JTextField jtNmCidade, jtIdcidade;
	public JComboBox jcEstados = null;
    public JButton jbSalvar, jbEditar, jbDeletar, jbProcurar;
	private JLabel jlNmCidade, jlEstado, jlIdCidade;
    private JPanel jpBotoes, jpCampos;
    private int acao;

    public CidadeView(String t, boolean r, boolean c, boolean m, boolean i, int acao) {
        super(t, r, c, m, i);
        this.acao = acao; 
        
        inicializaCampos();
        configuraLayout();

    }

    private void configuraLayout() {
        jpBotoes = new JPanel();
        jpBotoes.setLayout( new FlowLayout() );
        
        jpCampos = new JPanel();
        jpCampos.setLayout(new GridLayout(3,2) );
        
        jpCampos.add(jlIdCidade);
        jpCampos.add(jtIdcidade);
        jpCampos.add(jlNmCidade);
        jpCampos.add(jtNmCidade);
        jpCampos.add(jlEstado);
        jpCampos.add(jcEstados);
        
        switch (acao) {
            case ConstantesViews.SALVAR_CIDADE:
                jpBotoes.add(jbSalvar);
                break;
                
            case ConstantesViews.BUSCAR_CIDADE:
            	jpBotoes.add(jbProcurar);
            	break;
            	
            case ConstantesViews.DELETAR_CIDADE:
            	jpBotoes.add(jbDeletar);
            	break;
            	
            case ConstantesViews.EDITAR_CIDADE:
            	jpBotoes.add(jbEditar);
            	break;
        }
        
        this.setLayout(new BorderLayout() );
        Container container = this.getContentPane();
        
        container.add(BorderLayout.CENTER, jpCampos);
        container.add(BorderLayout.SOUTH, jpBotoes);
    }
    private void inicializaCampos() {
        jlIdCidade = new JLabel("Codigo:", SwingConstants.RIGHT);
        jlNmCidade = new JLabel("Nome:", SwingConstants.RIGHT);
        jlEstado = new JLabel("Estado:", SwingConstants.RIGHT);
        
        jtNmCidade = new JTextField();
        jtNmCidade.setDocument( new FixedLengthDocument(45) );
        jtIdcidade = new JTextField();
        
        if ( acao != ConstantesViews.BUSCAR_CIDADE) {
        	jtIdcidade.setEditable(false);
        }
        
        jcEstados = new JComboBox( new String[] {"RS","SC", "PR"});
        
        jbSalvar = new JButton();
        jbSalvar.setText("Salvar");
        jbSalvar.setMnemonic(KeyEvent.VK_S);
        
        jbEditar = new JButton();
        jbEditar.setText("Editar");
        jbEditar.setMnemonic(KeyEvent.VK_E);
        
        jbDeletar = new JButton();
        jbDeletar.setText("Deletar");
        jbDeletar.setMnemonic(KeyEvent.VK_D);
        
        jbProcurar = new JButton();
        jbProcurar.setText("Procurar");
        jbProcurar.setMnemonic(KeyEvent.VK_P);
    }
}
