package sc.br.senai.ctrl;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JOptionPane;

import sc.br.senai.ctrl.view.CidadeView;
import sc.br.senai.ctrl.view.TelaPrincipalView;
import sc.br.senai.dao.DAOFactory;
import sc.br.senai.model.Cidade;

/**
 *
 * @author artur
 */
public class ControleCidade {
    
    public CidadeView view;
    private Cidade c;
    
    public TelaPrincipalView principal;
    private ControleResultadoCidade crc;
    
    public ControleCidade(TelaPrincipalView principal, int acao) {
    	this(principal, acao, 0);
    }
    
    public ControleCidade(final TelaPrincipalView principal, int acao, final int depois) {
        view = new CidadeView("Cadastro cidade", true, true, true, true, acao);
        view.setVisible(true);
        
        this.principal = principal;
        
        view.jbSalvar.addActionListener( new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	c = getCidade();
                DAOFactory.getCidadeDAO().salvar(c);
                setCidade(c);
            }
        });
        
        view.jbProcurar.addActionListener( new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				c = getCidade();
				List<Cidade> cidades = DAOFactory.getCidadeDAO().buscaCidadesPorNome(c);
				if ( cidades.isEmpty() ) {
					JOptionPane.showMessageDialog(principal,
							"Busca sem Dados",
							"Busca sem Dados", JOptionPane.WARNING_MESSAGE);
				}
				view.setVisible(false);
				view = null;
				crc =  new ControleResultadoCidade(principal, cidades, depois);
				principal.desktop.add(BorderLayout.CENTER, crc.view);
			}
		});
        
        view.jbEditar.addActionListener( new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				c = getCidade();
				DAOFactory.getCidadeDAO().alterar(c);
			}
		});
        
        view.jbDeletar.addActionListener( new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				c = getCidade();
				DAOFactory.getCidadeDAO().deletar(c);
			}
		});
    }
    
    public void setCidade(Cidade c) {
    	view.jtIdcidade.setText( String.valueOf( c.getIdCidade() ) );
    	view.jtNmCidade.setText( c.getNmCidade() );
    	view.jcEstados.setSelectedItem( c.getSgEstado() );
    }
    
    public Cidade getCidade() {
    	c = new Cidade();
    	try {
    		c.setIdCidade( Integer.parseInt( view.jtIdcidade.getText() ) );
    	} catch (NumberFormatException ne) {}
    	c.setNmCidade( view.jtNmCidade.getText() );
    	c.setSgEstado( (String) view.jcEstados.getSelectedItem() );
    	
    	return c;
    }
}
