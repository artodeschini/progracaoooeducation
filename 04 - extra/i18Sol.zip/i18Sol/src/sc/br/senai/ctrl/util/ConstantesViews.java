/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sc.br.senai.ctrl.util;

/**
 *
 * @author artur
 */
public interface ConstantesViews {
    
    int SALVAR_CIDADE = 1;
    int EDITAR_CIDADE = 2;
    int DELETAR_CIDADE = 3;
    int BUSCAR_CIDADE = 4;
    
}
