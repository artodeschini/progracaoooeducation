package sc.br.senai.ctrl;

public class ControlePessoa {

}
