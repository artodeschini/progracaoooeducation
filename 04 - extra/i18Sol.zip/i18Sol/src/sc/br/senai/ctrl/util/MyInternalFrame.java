
package sc.br.senai.ctrl.util;

import javax.swing.JInternalFrame;

/**
 *
 * @author vdiguest0576
 */
public abstract class MyInternalFrame extends JInternalFrame {
    
	private static final long serialVersionUID = 2007539707588324014L;
	
	static final int xOffset = 30, yOffset = 30;
    static int openFrameCount = 0;
    
    public MyInternalFrame(String t, boolean  r, boolean c, boolean m, boolean i) {
        super(t, r, c, m, i);
        openFrameCount++;
        setSize(300,300);

        //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
    }
}
