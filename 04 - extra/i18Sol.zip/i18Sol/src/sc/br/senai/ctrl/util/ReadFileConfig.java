package sc.br.senai.ctrl.util;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;


/**
 *
 * @author vdiguest0576
 */
public class ReadFileConfig {
    
    public Map<String, String> getPropriedadeSistema(String path) throws IOException {
        return getPropriedadeSistema(path,"=");
    }

    public Map<String, String> getPropriedadeSistema(String path, String delim) throws IOException {
        Map<String, String> map = new HashMap<String, String>();
        String linha = null;
        BufferedReader in = new BufferedReader(new FileReader(path));

        while ((linha = in.readLine()) != null) {
            if (!linha.contains("#")) {
            	StringTokenizer st = new StringTokenizer(linha, delim);
                //String[] palavras = linha.split("=");
                //map.put(palavras[0], palavras[1]);
                map.put(st.nextToken(), st.nextToken());
            }
        }
        in.close();

        return map;
    }
    
    public Map<String, String> getPropriedadesSistema() throws IOException {
        return getPropriedadeSistema("src/sc/br/senai/dao/propriedade.properties");
    }
}
