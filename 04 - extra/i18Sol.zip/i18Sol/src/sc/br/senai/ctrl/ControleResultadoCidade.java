package sc.br.senai.ctrl;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import sc.br.senai.ctrl.view.ResultadoCidadeView;
import sc.br.senai.ctrl.view.TelaPrincipalView;
import sc.br.senai.model.Cidade;

public class ControleResultadoCidade {

	public ResultadoCidadeView view;
	private ControleCidade cc;

	public ControleResultadoCidade(final TelaPrincipalView principal, final List<Cidade> cidades, final int acao) {
		view = new ResultadoCidadeView("Resultado de Cidades", true, true, true, true, cidades);
		view.setVisible(true);

		view.jTable.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				view.setVisible(false);
				cc = new ControleCidade(principal, acao);
				principal.desktop.add(BorderLayout.CENTER, cc.view);

				int i = view.jTable.getSelectedRow();
				view = null;
				cc.setCidade( cidades.get(i) );
			}
		});
	}
}
