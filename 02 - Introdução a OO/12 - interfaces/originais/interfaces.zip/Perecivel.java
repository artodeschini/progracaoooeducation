
public interface Perecivel {

	int getTemperaturaConservacao();
	int getDiasValidade();
}
