
public interface Inflamavel extends Transportavel {
	
	int getTemperaturaMaxima();

}
