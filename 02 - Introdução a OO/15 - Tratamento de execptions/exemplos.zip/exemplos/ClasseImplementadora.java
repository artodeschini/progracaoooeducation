

public class ClasseImplementadora implements TesteException {

	@Override
	public void metodoA() throws BussinesException, RuntimeException {

	}
	
	//este m�todo n�o compilara
//	public void metodoA() throws IOException {
//		
//	}

}
