
public class TesteRunTime {
	
	public static void main(String[] args) {
		int i = 23;
		int j = 0;
		//erro de RunTime
		double res = i / j;
		System.out.println(i + " / " + j + " = " + res);
	}

}
