
public class TesteCriadorArquivos {
	
	public static void main(String[] args) {
		CriadorArquivos1 ca = new CriadorArquivos1();
		//Tentativa de chamarmos o codigo recem criado
		//nao compila pois precisariamos tratar o erro lan�ado
		//no metodo criarArquivo throws IOException
		//ca.criarArquivo("teste.txt");
	}

}
