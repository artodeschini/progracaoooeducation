
public class NumeroInvalidoException1 extends Exception {

	private static final long serialVersionUID = -2060260546936391686L;
	
	public NumeroInvalidoException1(String m) {
		super(m);
	}

}
