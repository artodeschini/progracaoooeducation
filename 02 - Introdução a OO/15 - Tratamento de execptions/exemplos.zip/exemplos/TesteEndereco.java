
public class TesteEndereco {
	
	public static void main(String[] args) throws NumeroInvalidoException1 {
		Endereco e = new Endereco("SC 401", 3730);
	}

}
