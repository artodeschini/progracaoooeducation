
public class NumeroInvalidoException extends Exception {

	private static final long serialVersionUID = -2060260546936391686L;

}
