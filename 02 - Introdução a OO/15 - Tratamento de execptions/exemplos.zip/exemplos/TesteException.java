
public interface TesteException {
	
	public void metodoA() throws BussinesException, RuntimeException;

}
