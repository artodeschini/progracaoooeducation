import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;

import sc.br.senai.ctrl.ControleTelaPrincipal;
import sc.br.senai.ctrl.util.LocalPadraoSistema;
import sc.br.senai.ctrl.view.SelecionaLocal;


/**
 * @author senai
 */
public class Run {
    
    private static LocalPadraoSistema lps;
    private static SelecionaLocal sl;
    
    public static void main(String[] args) {
        sl = new SelecionaLocal();

        //1 Descomente essa linha a baixo.
        //sl.setVisible(true);
        
        //2 comente essa linha
        executeTelaPrincipal();
        
        sl.jbIngles.addActionListener( new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	//3 chame o metodo criado passando em LocalPadraoSistema passando um
            	//Locale en US
            	
            	
            	//4 chame o metodo executeTelaPrincipal
                
            }
        });
       
      
       sl.jbPortugues.addActionListener( new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	//5 chame o metodo criado passando em LocalPadraoSistema passando um
            	//Locale pt BR
            	
            	
            	//6 chame o metodo executeTelaPrincipal
            }
        });
    }
    
    private static void executeTelaPrincipal() {
    	sl.setVisible(false);
        ControleTelaPrincipal cp = new ControleTelaPrincipal();
        cp.execute();
    }
    
}
