package sc.br.senai.ctrl;
import sc.br.senai.ctrl.view.TelaPrincipalView;

/**
 *
 * @author senai
 */
public class ControleTelaPrincipal {
    
    private TelaPrincipalView principal;
    
    public ControleTelaPrincipal() {
        principal = new TelaPrincipalView();
        principal.setVisible(true);
    }
    
    public void execute() {
    	principal.setVisible(true);
    }
    
}
