package sc.br.senai.ctrl.view;

import java.awt.Container;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

/**
 *
 * @author senai
 */
public class SelecionaLocal extends JFrame {
    
	private static final long serialVersionUID = -1070775421893552285L;
	
	public JButton jbPortugues, jbIngles;
    
    public SelecionaLocal() {
        this.setTitle("Selecione:");
        this.setSize(200, 100);
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        
        jbPortugues = new JButton("Portugues");
        jbIngles = new JButton("Ingles");
        
        Container c = this.getContentPane();
        
        this.setLayout( new FlowLayout() );
        
        c.add(jbPortugues);
        c.add(jbIngles);
    }
    
    
}
