package sc.br.senai.ctrl.view;

import java.util.ResourceBundle;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import sc.br.senai.ctrl.util.LocalPadraoSistema;

/**
 * @author senai
 */
public class TelaPrincipalView extends JFrame {

    private static final long serialVersionUID = 2326545281342207248L;
    public JMenuBar jmb = null;
    public JMenu jmp = null;
    public JMenu jmc = null;
    public JMenuItem jmica = null;
    public JMenuItem jmice = null;
    public JMenuItem jmicd = null;
    public JMenuItem jmipa = null;
    public JMenuItem jmipe = null;
    public JMenuItem jmipd = null;
    public JDesktopPane desktop = null;

    public TelaPrincipalView() {
        
    	/*
    	 * Analise essa parte do c�digo
    	 */
        ResourceBundle rotulos =
                ResourceBundle.getBundle("rotulos",
                LocalPadraoSistema.getLocalPadraoSistema());
       
        this.setTitle(rotulos.getString("tela.principal.titulo"));
        this.setSize(300, 300);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        jmb = new JMenuBar();

        jmp = new JMenu(rotulos.getString("tela.principal.menu.pessoa"));
        jmp.setMnemonic(rotulos.getString("tela.principal.menu.pessoa.atalho").charAt(0));

        jmc = new JMenu(rotulos.getString("tela.principal.menu.cidade"));
        jmc.setMnemonic(rotulos.getString("tela.principal.menu.cidade.atalho").charAt(0));
        
        jmica = new JMenuItem(rotulos.getString("tela.principal.item.adicionar"));
        jmice = new JMenuItem(rotulos.getString("tela.principal.item.editar"));
        jmicd = new JMenuItem(rotulos.getString("tela.principal.item.excluir"));

        jmipa = new JMenuItem(rotulos.getString("tela.principal.item.adicionar"));
        jmipe = new JMenuItem(rotulos.getString("tela.principal.item.editar"));
        jmipd = new JMenuItem(rotulos.getString("tela.principal.item.excluir"));

        jmc.add(jmica);
        jmc.add(jmice);
        jmc.add(jmicd);

        jmp.add(jmipa);
        jmp.add(jmipe);
        jmp.add(jmipd);

        jmb.add(jmc);
        jmb.add(jmp);

        this.setJMenuBar(jmb);

        desktop = new JDesktopPane(); //a specialized layered pane
        this.setContentPane(desktop);

        //Make dragging a little faster but perhaps uglier.
        desktop.setDragMode(JDesktopPane.OUTLINE_DRAG_MODE);
    }
}
