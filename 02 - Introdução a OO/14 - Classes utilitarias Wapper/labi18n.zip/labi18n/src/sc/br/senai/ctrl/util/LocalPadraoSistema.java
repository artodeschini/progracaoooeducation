package sc.br.senai.ctrl.util;

import java.util.Locale;
import java.util.ResourceBundle;

/**
 *
 * @author senai
 */
public class LocalPadraoSistema {

    private static Locale local = null;

    public static Locale getLocalPadraoSistema() {
        if (local == null) {
            ResourceBundle bundle = ResourceBundle.getBundle("propriedade");
            local = new Locale(
                    bundle.getString("lang"),
                    bundle.getString("coutry"));
        }

        return local;
    }
    
    /*
     * Crie um m�todo statico que receba como parametro Locale
     * e altere a variavel local dessa classe. 
     */

}
